# Pass the Check

## Challenge Description

A locked gate checks a secret code. Can you open the gate?

**MD5 Hash**: 4d8e51a9b8ac3e8ed5e6d14da5269553

## Short Writeup

gets() reads into a small buffer, followed by an integer comparison. Overflow to overwrite the integer variable and call the flag function.

## Flag

bi0s{v4r_0v3rwr1t3}

## Author

**Hellothere**