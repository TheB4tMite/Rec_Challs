# Code Runner

## Challenge Description

The system blindly trusts whatever code you feed it — if you can craft the right sequence of bytes, you’ll command the machine directly.

**MD5 Hash**: 551cf74c0be5ccd430a3f7e2d79a550b

## Short Writeup

The program takes user input and executes it. No restrictions for the shellcode.

## Flag

bi0s{sh3llc0d3_41nt_th47_h4rd}

## Author

**Hellothere**